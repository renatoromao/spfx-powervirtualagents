import "./chatbotWebpart/utilities/chatbot";
//# sourceMappingURL=index.d.ts.map