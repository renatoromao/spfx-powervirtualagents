import "./chatbot.js";
//# sourceMappingURL=chatbot.d.ts.map