import * as React from 'react';
import { IChatbotWebpartProps } from './IChatbotWebpartProps';
import "../utilities/webchat.js";
export default class ChatbotWebpart extends React.Component<IChatbotWebpartProps, {
    checked?: boolean;
}> {
    constructor(props: IChatbotWebpartProps);
    render(): React.ReactElement<IChatbotWebpartProps>;
}
//# sourceMappingURL=ChatbotWebpart.d.ts.map