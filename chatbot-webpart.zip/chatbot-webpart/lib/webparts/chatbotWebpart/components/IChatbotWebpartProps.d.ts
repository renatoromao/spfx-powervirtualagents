export interface IChatbotWebpartProps {
    botid: string;
    botname: string;
    botimage: string;
    botlogo: string;
}
//# sourceMappingURL=IChatbotWebpartProps.d.ts.map