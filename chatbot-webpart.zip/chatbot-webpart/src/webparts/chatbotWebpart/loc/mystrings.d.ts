declare interface IChatbotWebpartWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ChatbotWebpartWebPartStrings' {
  const strings: IChatbotWebpartWebPartStrings;
  export = strings;
}
