export interface IChatbotWebpartProps {
  botid: string;
  botname: string;
  botimage: string;
  botlogo: string;
}
